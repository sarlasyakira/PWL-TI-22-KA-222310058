import moment from "moment";
import React from "react";

const styleChatItems = {
  chatBubleItems: {
    display: "flex",
    flexDirection: "column",
  },
  chatBubleSender: {
    textAlign: "right",
    backgroundColor: "#a198a7",
    alignSelf: "flex-end",
    padding: "10px",
    borderRadius: "10px",
    margin: "5px",
  },
  chatBubleReceiver: {
    backgroundColor: "#a83aef",
    alignSelf: "flex-start",
    padding: "10px",
    borderRadius: "10px",
    margin: "5px",
  },
};

export default function ChatBody({ data }) {
  const listdata = [...data];
  
  // Urutkan chat berdasarkan tanggal
  listdata.sort((a, b) => new Date(a.date) - new Date(b.date));
  
  const itsme = "Febry"; // atau nama login user

  return (
    <div className="chat-items" style={styleChatItems.chatBubleItems}>
      {listdata.map((v, index) => (
        <div
          key={index}
          className="chat text-white rounded my-2 p-2"
          style={v.from === itsme ? styleChatItems.chatBubleSender : styleChatItems.chatBubleReceiver}
        >
          <span className="me-3">{v.message}</span>
          <span className="chat-date" style={{ fontSize: "11px" }}>
            {moment(v.date).format("HH:mm")}
          </span>
        </div>
      ))}
    </div>
  );
}
