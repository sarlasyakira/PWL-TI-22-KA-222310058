import React from 'react';

export default function Footers() {
  return (
    <div>
      <div className="">
        <div className="">
          <span>2024 ©</span>
          <span>IBI Kesatuan Bogor</span>
        </div>
      </div>
    </div>
  );
}
