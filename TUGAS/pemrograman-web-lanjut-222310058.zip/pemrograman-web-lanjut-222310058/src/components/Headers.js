import React from 'react';

export default function Headers() {
  return (
    <div>
      <h1>IBI Kesatuan</h1>
      <ul className="">
        <li>Home</li>
        <li>PWL</li>
      </ul>
    </div>
  );
}
