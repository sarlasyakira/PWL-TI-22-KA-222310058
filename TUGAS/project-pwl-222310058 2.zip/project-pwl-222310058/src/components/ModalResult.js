import React from 'react';
import { Modal, Button } from 'react-bootstrap';

function calculateAge(birthdate) {
  const today = new Date();
  const birthDate = new Date(birthdate);
  let age = today.getFullYear() - birthDate.getFullYear();
  const monthDiff = today.getMonth() - birthDate.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }
  return age;
}

export default function ModalResult({ show, handleClose, data }) {
  const fullname = [data.firstName, data.middleName, data.lastName]
    .filter(Boolean)
    .join(' ');
  const age = data.birthdate ? calculateAge(data.birthdate) : '';

  return (
    <Modal show={show} onHide={handleClose}>
      <Modal.Header closeButton>
        <Modal.Title>Data Diri</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <p><strong>NPM:</strong> {data.npm}</p>
        <p><strong>Fullname:</strong> {fullname}</p>
        <p><strong>Age:</strong> {age} tahun</p>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={handleClose}>
          Close
        </Button>
      </Modal.Footer>
    </Modal>
  );
}
