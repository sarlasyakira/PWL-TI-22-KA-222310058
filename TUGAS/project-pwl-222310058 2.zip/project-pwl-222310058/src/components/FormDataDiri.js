import React, { useState } from 'react';
import ModalResult from './ModalResult';
import { Button, Form } from 'react-bootstrap';

export default function FormDataDiri() {
  const [show, setShow] = useState(false);
  const [formData, setFormData] = useState({
    npm: '',
    firstName: '',
    middleName: '',
    lastName: '',
    birthdate: ''
  });
  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === "npm") {
      if (isNaN(value)) return; // hanya angka
      if (value.length > 10) return; // maksimal 10 digit
    }
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const validateForm = () => {
    const newErrors = {};
    if (!formData.npm) newErrors.npm = "NPM wajib diisi";
    if (!formData.firstName) newErrors.firstName = "First Name wajib diisi";
    if (!formData.lastName) newErrors.lastName = "Last Name wajib diisi";
    if (!formData.birthdate) newErrors.birthdate = "Birthdate wajib diisi";
    return newErrors;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const validationErrors = validateForm();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
    } else {
      setErrors({});
      setShow(true);
    }
  };

  return (
    <>
      <Form onSubmit={handleSubmit} className="p-4">
        <Form.Group className="mb-3">
          <Form.Label>NPM</Form.Label>
          <Form.Control
            type="text"
            name="npm"
            value={formData.npm}
            onChange={handleChange}
            maxLength="10"
          />
          {errors.npm && <div className="text-danger">{errors.npm}</div>}
        </Form.Group>

        <Form.Group className="mb-3">
          <Form.Label>First Name</Form.Label>
          <Form.Control
            type="text"
            name="firstName"
            value={formData.firstName}
            onChange={handleChange}
          />
          {errors.firstName && <div className="text-danger">{errors.firstName}</div>}
        </Form.Group>

        <Form.Group className="mb-3">
          <Form.Label>Middle Name (Optional)</Form.Label>
          <Form.Control
            type="text"
            name="middleName"
            value={formData.middleName}
            onChange={handleChange}
          />
        </Form.Group>

        <Form.Group className="mb-3">
          <Form.Label>Last Name</Form.Label>
          <Form.Control
            type="text"
            name="lastName"
            value={formData.lastName}
            onChange={handleChange}
          />
          {errors.lastName && <div className="text-danger">{errors.lastName}</div>}
        </Form.Group>

        <Form.Group className="mb-3">
          <Form.Label>Birthdate (YYYY-MM-DD)</Form.Label>
          <Form.Control
            type="date"
            name="birthdate"
            value={formData.birthdate}
            onChange={handleChange}
          />
          {errors.birthdate && <div className="text-danger">{errors.birthdate}</div>}
        </Form.Group>

        <Button variant="primary" type="submit">
          Submit
        </Button>
      </Form>

      <ModalResult show={show} handleClose={() => setShow(false)} data={formData} />
    </>
  );
}
