import React from 'react';
import FormDataDiri from './components/FormDataDiri'; // kita mau buat file ini nanti

function App() {
  return (
    <div className="container mt-5">
      <h1 className="text-center mb-4">Form Data Diri</h1>
      <FormDataDiri />
    </div>
  );
}

export default App;
