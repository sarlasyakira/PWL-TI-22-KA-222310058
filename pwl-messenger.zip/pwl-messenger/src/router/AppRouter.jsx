// src/router/AppRouter.jsx
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import AuthPage from '../pages/AuthPage';
import ChapterOne from '../pages/ChapterOne';
import ChapterTwo from '../pages/ChapterTwo';
import ErrorPage from '../pages/ErrorPage';

export default function AppRouter() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="*" element={<AuthPage />} />
        <Route path="/sign-in" element={<AuthPage />} />
        <Route path="/sign-out" element={<AuthPage />} />
        <Route path="/chapter-1" element={<ChapterOne />} />
        <Route path="/chapter-2" element={<ChapterTwo />} />
        <Route path="/home" element={<ChapterTwo />} />
        <Route path="*" element={<ErrorPage />} />
      </Routes>
    </BrowserRouter>
  );
}
