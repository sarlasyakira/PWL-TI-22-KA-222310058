const Chat_1 = [
    { id: 1, from_id: "0419029203", messages: "P", date: "2024-02-22 10:30:00", to_user_id: "123" },
    { id: 2, from_id: "123", messages: "Ke pasar beli mangga", date: "2024-02-22 10:30:00", to_user_id: "0419029203" },
  ];
  
  const Chat_2 = [
    { id: 1, from_id: "321", messages: "Nanya dong", date: "2024-02-22 20:10:00", to_user_id: "0419029203" },
    { id: 2, from_id: "0419029203", messages: "Kenapa?", date: "2024-02-22 20:15:00", to_user_id: "321" },
  ];
  
  const Messegers = [
    { chat_id: 1, user_id: "123", messages: Chat_1 },
    { chat_id: 2, user_id: "321", messages: Chat_2 },
  ];
  
  const MyFriend = [
    { id: 1, user_id: "123", name: "Septian" },
    { id: 2, user_id: "321", name: "Jemi" },
  ];
  
  export { Messegers, MyFriend };
  