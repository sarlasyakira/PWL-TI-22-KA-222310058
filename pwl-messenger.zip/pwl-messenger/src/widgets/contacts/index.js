import React, { useMemo, useState } from "react";

export function ContactUI({ my_account, friends, selectedUser, HandlerSelectedChat }) {
  const [search, setSearch] = useState('');
  const [sorting, setSorting] = useState({ field: '', order: '' });

  const ResultData = useMemo(() => {
    let computedData = [...friends];

    if (search) {
      computedData = computedData.filter((item) =>
        Object.keys(item).some((key) =>
          item[key].toString().toLowerCase().includes(search.toLowerCase())
        )
      );
    }

    if (sorting.field) {
      const reversed = sorting.order === "asc" ? 1 : -1;
      computedData.sort((a, b) =>
        reversed * a[sorting.field].localeCompare(b[sorting.field])
      );
    }

    return computedData;
  }, [friends, search, sorting]);

  const toggleSorting = (field) => {
    if (sorting.field === field) {
      setSorting({ ...sorting, order: sorting.order === 'asc' ? 'desc' : 'asc' });
    } else {
      setSorting({ field, order: 'asc' });
    }
  };

  return (
    <div style={{ borderRight: '1px solid #ccc', padding: '1rem' }}>
      <h3>Welcome, {my_account.name}</h3>
      <input
        placeholder="Search..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        style={{ width: '100%', marginBottom: '1rem' }}
      />
      <button onClick={() => toggleSorting('name')}>Sort by Name</button>

      {ResultData.length > 0 ? (
        ResultData.map((friend) => (
          <div
            key={friend.user_id}
            style={{
              padding: '0.5rem',
              backgroundColor: selectedUser?.user_id === friend.user_id ? '#e6f7ff' : '',
              cursor: 'pointer'
            }}
            onClick={() => HandlerSelectedChat(friend)}
          >
            <strong>{friend.name}</strong><br />
            <small>{friend.user_id}</small>
          </div>
        ))
      ) : (
        <p>No Data Found!</p>
      )}
    </div>
  );
}
