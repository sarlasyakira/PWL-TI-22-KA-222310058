import React, { useEffect, useMemo, useRef, useState } from "react";
import moment from "moment";

const EmptyChat = () => (
  <div style={{ textAlign: 'center', marginTop: '2rem' }}>
    <h2>No Conversations</h2>
    <p>Silakan pilih kontak untuk mulai chat</p>
  </div>
);

export function MessegersUI({ profile, selectedChat = [], selectedUser }) {
  const [myChat, setMyChat] = useState([]);
  const [search, setSearch] = useState('');
  const endRef = useRef(null);

  useEffect(() => {
    setMyChat(selectedChat);
    scrollToBottom();
  }, [selectedChat]);

  const scrollToBottom = () => {
    if (endRef.current) {
      endRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const ResultMessageData = useMemo(() => {
    let computedData = myChat.map((msg) => ({
      ...msg,
      date_fmt: moment(msg.date).format("HH:mm"),
      isOutgoing: msg.from_id === profile.id
    }));

    if (search) {
      computedData = computedData.filter((msg) =>
        msg.messages.toLowerCase().includes(search.toLowerCase())
      );
    }

    return computedData;
  }, [myChat, search, profile.id]);

  return (
    <div style={{ padding: '1rem', height: '100%' }}>
      {ResultMessageData.length > 0 ? (
        <>
          <h3>Chat with: {selectedUser?.name}</h3>
          <input
            placeholder="Search chat history..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            style={{ width: '100%', marginBottom: '1rem' }}
          />
          <div style={{ height: '300px', overflowY: 'auto', border: '1px solid #ccc', padding: '1rem' }}>
            {ResultMessageData.map((msg) => (
              <div
                key={msg.id}
                style={{
                  textAlign: msg.isOutgoing ? 'right' : 'left',
                  marginBottom: '1rem'
                }}
              >
                <span style={{
                  display: 'inline-block',
                  background: msg.isOutgoing ? '#dcf8c6' : '#f1f0f0',
                  padding: '0.5rem 1rem',
                  borderRadius: '1rem',
                }}>
                  {msg.messages} <br />
                  <small>{msg.date_fmt}</small>
                </span>
              </div>
            ))}
            <div ref={endRef}></div>
          </div>
        </>
      ) : (
        <EmptyChat />
      )}
    </div>
  );
}
