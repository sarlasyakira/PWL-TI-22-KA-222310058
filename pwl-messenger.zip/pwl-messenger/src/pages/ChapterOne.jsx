// src/pages/ChapterOne.jsx
export default function ChapterOne() {
    return (
      <div>
        <h1>Chapter One</h1>
      </div>
    );
  }
  