import { useState } from 'react';

export default function AuthPage() {
  const [form, setForm] = useState({
    username: '',
    password: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert(`Username: ${form.username}\nPassword: ${form.password}`);
  };

  return (
    <div style={{ padding: '2rem' }}>
      <h1>Authentication Page</h1>
  
      {/* ⬇️ Tambahin test di sini */}
      <p style={{ color: 'red' }}>INI TEST LINE DARI GUA</p>
  
      <form onSubmit={handleSubmit} style={{ maxWidth: '300px' }}>
        <div>
          <label>Username</label>
          <input
            type="text"
            name="username"
            value={form.username}
            onChange={handleChange}
            required
          />
        </div>
        <div style={{ marginTop: '1rem' }}>
          <label>Password</label>
          <input
            type="password"
            name="password"
            value={form.password}
            onChange={handleChange}
            required
          />
        </div>
        <button type="submit" style={{ marginTop: '1.5rem' }}>
          Login
        </button>
      </form>
    </div>
  )
};