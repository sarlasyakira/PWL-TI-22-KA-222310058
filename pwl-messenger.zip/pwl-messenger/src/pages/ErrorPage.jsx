// src/pages/ErrorPage.jsx
export default function ErrorPage() {
    return (
      <div>
        <h1>Error 404: Page Not Found</h1>
      </div>
    );
  }
  