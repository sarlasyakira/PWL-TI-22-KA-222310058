import React, { useState } from "react";
import { ContactUI } from "../widgets/contacts";
import { MessegersUI } from "../widgets/messengers";
import { Messegers, MyFriend } from "../widgets/constantas/DataChat";

export default function ChapterTwo() {
  const [selectedUser, setSelectedUser] = useState(null);
  const [selectedChat, setSelectedChat] = useState([]);

  const my_account = {
    id: "0419029203",
    name: "You",
  };

  const HandlerSelectedChat = (friend) => {
    const foundChat = Messegers.find((chat) => chat.user_id === friend.user_id);
    setSelectedChat(foundChat?.messages || []);
    setSelectedUser(friend);
  };

  // 🔍 Tes apakah komponen ke-load
  console.log("ContactUI: ", ContactUI);
  console.log("MessegersUI: ", MessegersUI);

  return (
    <div style={{ display: "flex", height: "100vh" }}>
      <div style={{ width: "25%" }}>
        <ContactUI
          my_account={my_account}
          friends={MyFriend}
          selectedUser={selectedUser}
          HandlerSelectedChat={HandlerSelectedChat}
        />
      </div>
      <div style={{ width: "75%" }}>
        <MessegersUI
          profile={my_account}
          selectedChat={selectedChat}
          selectedUser={selectedUser}
        />
      </div>
    </div>
  );
}
